﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkToApi.Helpers.Contants
{
    public class CustomMediaType
    {
        public const string Hateoas = "application/vnd.talkto.hateoas+json";
    }
}
